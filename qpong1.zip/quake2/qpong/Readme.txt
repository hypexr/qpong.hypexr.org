
                        QPong (C) 1998 David Wallin

        "It F***ING ROCKS F***ING HARD THE BEST MOD F***ING EVER!"
                                        - Fragmaster, Planetquake



CONTENTS

1. What is QPong?
2. Player Commands
3. Setting up a Server
4. Server Variables
5. Maps
6. Future Plans
7. Credits

-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

1. What is QPong?

	QPong is a teamplay mod unlike any other. Two to four teams face off in an arena, each with their own goal. As the match commences, a gigantic steel ball is dropped into the arena
for each team. The objective is to manuever any of the balls into your opponents goal. Each 
team starts with 5 points, and each time you score on them, they lose one point. When a team
reaches zero, they are eliminated from the match and become observers (alternately, they can
join the teams which are still playing). The challenge to QPong comes from moving the ball. The ball can be pushed or you can blast it with your weapons, causing it to roll at incredible speeds. The balls (which are larger than your character) can be used to crush other players, which makes staying alive a challenge as well. The ball becomes a viable way to kill any player (in addition to being highly enjoyable). Also, walking into your own goal provides you with temporary invulnerability to the ball (players can still kill you). With this invulnerability, you can play goalie and stop balls with your body. Most levels feature Pinball paddles which will deflect any shots on the goal which don't come down the center. QPong also features running commentary from announcers and a number of server options to keep things interesting.

2. Player commands

cmd changeteam OR cmd team - Bring up a menu to change your team
cmd ident OR cmd id - Identify the person standing beneath your crosshair
cmd maplist - Get a list of maps the server is running

Note: The taunt commands now have voices associated with them.

3. Setting up a server

Here's an average command line for QPONG:

quake2 +set game "qpong" +deathmatch 1 +maxclients 16 +map qpong1

You might also want to add some of the commands which are in the next section.

You can also set up your MOTD.TXT which is in the qpong directory to display a short message
about your server (possibly with your server name, ect).

The BALLS.TXT sets which ball models are used the game. New ball models can be added, but EVERYONE who plays must have the model. Otherwise they get a crappy white cube instead of a ball (or no ball at all). It's not recommended that you add custom balls unless you're running a LAN
game and can ensure that everyone has the files. However, removing balls is fine (say, you don't want the smiley face ball). Just delete that line in the text file.

MAPS.TXT sets the maps which are rotated thru as a level completes. It will not load up a map
as soon as you start QPong.. You still should start out on a map in your command line.

Setting the fraglimit will cause the game to end once a TEAM's FRAGS have passed the limit. I don't think timed matches (timelimit) are implemented currently.

You may want to take advantage of the players_per_team cvar.. It is recommended that team sizes not
exceed 4 players. The more players you have on a team, the more chaotic things get.

4. Server Commands

vwep_support - Toggle vwep support (1 is on, 0 is off). Default: off
min_players - Number of players per team that the game will wait for, before dropping the ball. Default: 2 per team
ball_weight - Weight of the ball. 100 is default. 50 is light, 200 is heavy. This will only be
applied to a ball when it is spawned.. it has no effect on balls already spawned
balls_per_team - Number of balls spawned per team. Fractional values are accepted. Default: 1 ball per team.
players_per_team - Maximum number of players per team.. Default: 8
start_score - Starting score of teams.. 5 is default. Use 10 for longer games. 1 for sudden 	death, ect.
assign_teams - 1 for true, 0 for false. Default: off.
announcers - 1 or 0. Default: 1. Use to toggle announcer comments.

Note: You will need the pack file for VWEP if you want to use it. VWEP can be found at www.telefragged.com/tsunami.

5. Valid Maps

QPong1 (The Pipe) - 2 teams (WhiteNoise)
QPong2 (Dr. Pok) - 2 teams (Kolinarh)
QPong3 (Great Balls of Fire) - 2 teams (Guru)

6. Future Plans

* More levels
* Announcer packs
* QPong Ball packs
* More levels
* New player models for observers (maybe)
* Arena Level - play for frags (smash each other with qpong balls)
* Three and Four team levels

7. Credits

David "WhiteNoise" Wallin - All coding, maps, models, art
"Guru" - Maps
Brad "Technomage" Herman - Intro movie, ball model.
"Kolinahr" - Maps
Nate "Mechanized Grandpa" Kozloski - Sound effects
Helder "Heldog" Vicente  - Announcer voice
Chris "Grifter"	- Announcer voice

Planetquake Staff - Beta Testing
